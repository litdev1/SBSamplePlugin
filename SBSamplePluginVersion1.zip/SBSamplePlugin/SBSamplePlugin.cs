﻿using SB_IDE; // Requires reference to SB-IDE.exe
using System.Drawing;

namespace SBSamplePlugin
{
    // A simple plugin example
    // Once it is complied copy just the resulting dll (SBSamplePlugin.dll) to a folder called plugins (sub folder to where SB-IDE.exe is located)
    [SBplugin]
    public static class SBSamplePlugin
    {
        // Set the name for the plugin
        public static string GetName()
        {
            return "SamplePlugin";
        }

        // Set a bitmap image for the plugin
        public static Bitmap GetBitmap()
        {
            return Properties.Resources.plugin;
        }

        // Set a tooltip description for the plugin
        public static string GetToolTip()
        {
            return "My SamplePlugin";
        }

        // Perform an action for the plugin (text will be the current Small Basic document text
        public static bool Run(string text)
        {
            // In this case a simple form displaying the document text
            Form1 form1 = new Form1(text);
            form1.ShowDialog();
            return true;
        }
    }
}
